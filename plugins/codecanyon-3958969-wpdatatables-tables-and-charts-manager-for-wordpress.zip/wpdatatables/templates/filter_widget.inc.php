<div id="wdtFilterWidget" class="wpDataTables">
	<h2><?php echo $title ?></h2>
	<button class="button btn wdtClearFilters" style="margin-bottom: 10px;"><?php _e('Clear filters','wpdatatables'); ?></button>
</div>